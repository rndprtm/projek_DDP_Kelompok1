import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import ttkbootstrap as ttk
from ttkbootstrap.constants import *

def welcome_message():
    messagebox.showinfo("Welcome", "Selamat datang di Aplikasi Library Book List!\nProgram ini memungkinkan Anda untuk menambah, menampilkan, mengupdate, dan menghapus informasi buku.")

def create_new_book():
    book_id = entry_book_id.get()

    # Check if ID already exists
    if check_duplicate_id(book_id):
        messagebox.showerror("Error", "ID SUDAH TERDAFTAR. Masukkan ID yang berbeda.")
        return

    title = entry_title.get()
    author = entry_author.get()

    try:
        pages = int(entry_pages.get())
    except ValueError:
        messagebox.showerror("Error", "Masukkan angka yang valid untuk jumlah halaman.")
        return

    genre = entry_genre.get()

    with open("library_books.txt", "a") as file:
        file.write(f"{book_id},{title},{author},{pages},{genre}\n")
    messagebox.showinfo("Success", "Buku berhasil ditambahkan!")

def check_duplicate_id(book_id):
    with open("library_books.txt", "r") as file:
        lines = file.readlines()
        for line in lines:
            existing_id = line.split(",")[0]
            if existing_id == book_id:
                return True
    return False

def display_list_of_books():
    result = "Daftar Buku:\n"
    try:
        with open("library_books.txt", "r") as file:
            for line in file:
                result += line.strip() + "\n"
    except FileNotFoundError:
        result = "Tidak ada buku yang terdaftar."
    
    messagebox.showinfo("Daftar Buku", result)

def update_book_information():
    book_id = entry_update_book_id.get()
    updated_id = entry_updated_id.get() or book_id
    updated_title = entry_updated_title.get() or ""
    updated_author = entry_updated_author.get() or ""

    try:
        updated_pages = int(entry_updated_pages.get()) if entry_updated_pages.get() else None
    except ValueError:
        messagebox.showerror("Error", "Masukkan angka yang valid untuk jumlah halaman.")
        return

    updated_genre = entry_updated_genre.get() or ""

    try:
        with open("library_books.txt", "r") as file:
            lines = file.readlines()
        with open("library_books.txt", "w") as file:
            for line in lines:
                current_id, current_title, current_author, current_pages, current_genre = line.strip().split(",")
                if current_id == book_id:
                    updated_id = updated_id if updated_id else current_id
                    updated_title = updated_title if updated_title else current_title
                    updated_author = updated_author if updated_author else current_author
                    updated_pages = updated_pages if updated_pages is not None else current_pages
                    updated_genre = updated_genre if updated_genre else current_genre
                    file.write(f"{updated_id},{updated_title},{updated_author},{updated_pages},{updated_genre}\n")
                else:
                    file.write(line)
        messagebox.showinfo("Success", "Informasi buku berhasil diupdate!")
    except FileNotFoundError:
        messagebox.showerror("Error", "Tidak ada buku yang terdaftar.")

def delete_book():
    book_title = entry_delete_book_title.get()

    try:
        with open("library_books.txt", "r") as file:
            lines = file.readlines()
        with open("library_books.txt", "w") as file:
            book_found = False
            for line in lines:
                current_title = line.split(",")[1]
                if current_title.strip() == book_title:
                    book_found = True
                    messagebox.showinfo("Success", f"Buku dengan judul '{book_title}' berhasil dihapus.")
                else:
                    file.write(line)
            if not book_found:
                messagebox.showinfo("Not Found", f"Buku dengan judul '{book_title}' tidak ditemukan.")
    except FileNotFoundError:
        messagebox.showerror("Error", "Tidak ada buku yang terdaftar.")

def main():
    welcome_message()

    root = tk.Tk()
    root.title("Aplikasi Library Book List")

    style = ttk.Style()
    style.configure("TButton", padding=6, relief="flat")

    frame = ttk.Frame(root, padding="10")
    frame.grid(column=0, row=0, sticky=(tk.W, tk.E, tk.N, tk.S))

    ttk.Label(frame, text="Tambah Buku Baru:").grid(column=0, row=0, columnspan=2, pady=5)
    ttk.Label(frame, text="ID Buku:").grid(column=0, row=1, sticky=tk.E)
    ttk.Label(frame, text="Judul Buku:").grid(column=0, row=2, sticky=tk.E)
    ttk.Label(frame, text="Nama Pengarang:").grid(column=0, row=3, sticky=tk.E)
    ttk.Label(frame, text="Jumlah Halaman:").grid(column=0, row=4, sticky=tk.E)
    ttk.Label(frame, text="Genre Buku:").grid(column=0, row=5, sticky=tk.E)

    global entry_book_id, entry_title, entry_author, entry_pages, entry_genre
    entry_book_id = ttk.Entry(frame)
    entry_title = ttk.Entry(frame)
    entry_author = ttk.Entry(frame)
    entry_pages = ttk.Entry(frame)
    entry_genre = ttk.Entry(frame)

    entry_book_id.grid(column=1, row=1, sticky=tk.W)
    entry_title.grid(column=1, row=2, sticky=tk.W)
    entry_author.grid(column=1, row=3, sticky=tk.W)
    entry_pages.grid(column=1, row=4, sticky=tk.W)
    entry_genre.grid(column=1, row=5, sticky=tk.W)

    ttk.Button(frame, text="Tambah Buku", command=create_new_book, bootstyle=DARK).grid(column=0, row=6, columnspan=2, pady=10)

    ttk.Label(frame, text="Daftar Buku:").grid(column=0, row=7, columnspan=2, pady=5)
    ttk.Button(frame, text="Tampilkan Daftar Buku", command=display_list_of_books, bootstyle=DARK).grid(column=0, row=8, columnspan=2, pady=10)

    ttk.Label(frame, text="Perbarui Informasi Buku:").grid(column=0, row=9, columnspan=2, pady=5)
    ttk.Label(frame, text="Masukkan ID Buku yang ingin diupdate:").grid(column=0, row=10, sticky=tk.E)
    ttk.Label(frame, text="Masukkan ID baru:").grid(column=0, row=11, sticky=tk.E)
    ttk.Label(frame, text="Masukkan Judul baru:").grid(column=0, row=12, sticky=tk.E)
    ttk.Label(frame, text="Masukkan Nama Pengarang baru:").grid(column=0, row=13, sticky=tk.E)
    ttk.Label(frame, text="Masukkan Jumlah Halaman baru:").grid(column=0, row=14, sticky=tk.E)
    ttk.Label(frame, text="Masukkan Genre Buku baru:").grid(column=0, row=15, sticky=tk.E)

    global entry_update_book_id, entry_updated_id, entry_updated_title, entry_updated_author, entry_updated_pages, entry_updated_genre
    entry_update_book_id = ttk.Entry(frame)
    entry_updated_id = ttk.Entry(frame)
    entry_updated_title = ttk.Entry(frame)
    entry_updated_author = ttk.Entry(frame)
    entry_updated_pages = ttk.Entry(frame)
    entry_updated_genre = ttk.Entry(frame)

    entry_update_book_id.grid(column=1, row=10, sticky=tk.W)
    entry_updated_id.grid(column=1, row=11, sticky=tk.W)
    entry_updated_title.grid(column=1, row=12, sticky=tk.W)
    entry_updated_author.grid(column=1, row=13, sticky=tk.W)
    entry_updated_pages.grid(column=1, row=14, sticky=tk.W)
    entry_updated_genre.grid(column=1, row=15, sticky=tk.W)

    ttk.Button(frame, text="Perbarui Informasi Buku", command=update_book_information, bootstyle=DARK).grid(column=0, row=16, columnspan=2, pady=10)

    ttk.Label(frame, text="Hapus Buku:").grid(column=0, row=17, columnspan=2, pady=5)
    ttk.Label(frame, text="Masukkan Judul Buku yang ingin dihapus:").grid(column=0, row=18, sticky=tk.E)

    global entry_delete_book_title
    entry_delete_book_title = ttk.Entry(frame)
    entry_delete_book_title.grid(column=1, row=18, sticky=tk.W)

    ttk.Button(frame, text="Hapus Buku", command=delete_book, bootstyle=DARK).grid(column=0, row=19, columnspan=2, pady=10)

    root.mainloop()

if __name__ == "__main__":
    main()
